package com.niiit.Shopcart.DAO;

import java.util.List;

import com.niit.Shopcart.model.Category;

public interface CategoryDAO {
    
	public List<Category> list ();
	public Category get (String Cat_id);
	public Category getByName(String name);
	public void saveOrUpdate (Category category);
	public void delete (String Cat_id);
}
