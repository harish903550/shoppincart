package com.niiit.Shopcart.DAO;

import java.util.List;

import com.niit.Shopcart.model.Product;

public interface ProductDAO {
	
	public List<Product> list();
	public Product get(String Pro_id);
	public void saveOrUpdate(Product product);
	public void delete(String pro_id);
	

}
