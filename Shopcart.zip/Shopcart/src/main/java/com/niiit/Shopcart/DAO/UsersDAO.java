package com.niiit.Shopcart.DAO;

import java.util.List;

import com.niit.Shopcart.model.Users;

public interface UsersDAO {
	public List<Users> list ();
	public Users get(String use_id);
	public void saveOrUpdate (Users users);
	public void delete (String use_id);
	public boolean isValiduser(String use_name, String use_password);

}
