package com.niiit.Shopcart.DAO;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.Shopcart.model.Users;

@Repository("usersDAO")
public class UsersDAOImpl implements UsersDAO {
	
    @Autowired
    private SessionFactory sessionFactory;
	private String use_id;
    public UsersDAOImpl(SessionFactory sessionFactory) {
    	this.sessionFactory = sessionFactory;
    }
    

    @Transactional
	public List<Users> list() {
		@SuppressWarnings("unchecked")
		List<Users> listUser = (List<Users>)
		     sessionFactory.getCurrentSession()
		     .createCriteria(Users.class)
		     .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listUser;
	}

    @Transactional
	public Users get(String Use_id) {
    	String hq1 = "from User when id= "+"'"+Use_id+"'";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hq1);
		List<Users> listUser = (List<Users>) query.getResultList();
		
		if (listUser != null && !listUser.isEmpty())
		{return listUser.get(0);}	
		return null;
	}

    @Transactional
	public void saveOrUpdate(Users users) {
    	sessionFactory.getCurrentSession().saveOrUpdate(users);
	
		
	}
    @Transactional
	public void delete(String Use_id) {
	    Users userToDelete = new Users();
	    userToDelete.setUse_id(use_id);
	    sessionFactory.getCurrentSession().delete(userToDelete);
	}


    @Transactional
	public boolean isValiduser(String use_name, String use_password) {
		
		
String hql = "from Users where use_name= '"+use_name+"' and "+" use_password = '"+use_password+"' ";
				Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
				@SuppressWarnings("unchecked")
				List<Users> list = (List<Users>)  query.getResultList();
				if(list != null && !list.isEmpty())
				{
					System.out.println("done");
				return true;
				}
				else
				{
					System.out.println("no");
					return false;
				}
			}



	}
	

	


