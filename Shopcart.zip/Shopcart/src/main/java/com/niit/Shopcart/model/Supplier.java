package com.niit.Shopcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Supplier")
@Component
public class Supplier {

	@Id
	private String Sup_id;
	private String Sup_name;
	private String Sup_addr;
	
	public String getSup_id() {
		return Sup_id;
	}
	public void setSup_id(String sup_id) {
		Sup_id = sup_id;
	}
	public String getSup_name() {
		return Sup_name;
	}
	public void setSup_name(String sup_name) {
		Sup_name = sup_name;
	}
	public String getSup_addr() {
		return Sup_addr;
	}
	public void setSup_addr(String sup_addr) {
		Sup_addr = sup_addr;
	}
	
	
	
	
}
