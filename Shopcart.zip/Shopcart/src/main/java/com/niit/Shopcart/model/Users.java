package com.niit.Shopcart.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



@Entity
@Table(name = "Users")
@Component
public class Users {

@Id
private String Use_id;
private String Use_name;
private String Use_password;
private String Use_PH;
private String Use_Emailid;
private String Use_Addr;
public String getUse_id() {
	return Use_id;
}
public void setUse_id(String use_id) {
	Use_id = use_id;
}
public String getUse_name() {
	return Use_name;
}
public void setUse_name(String use_name) {
	Use_name = use_name;
}
public String getUse_password() {
	return Use_password;
}
public void setUse_password(String use_password) {
	Use_password = use_password;
}
public String getUse_PH() {
	return Use_PH;
}
public void setUse_PH(String use_PH) {
	Use_PH = use_PH;
}
public String getUse_Emailid() {
	return Use_Emailid;
}
public void setUse_Emailid(String use_Emailid) {
	Use_Emailid = use_Emailid;
}
public String getUse_Addr() {
	return Use_Addr;
}
public void setUse_Addr(String use_Addr) {
	Use_Addr = use_Addr;
}







}
