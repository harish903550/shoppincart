package com.niit.Shopcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niiit.Shopcart.DAO.CategoryDAO;
import com.niit.Shopcart.model.Category;


public class CategoryTest {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		Category category = (Category) context.getBean("category");
		
		category.setCat_des("new");
		category.setCat_id("cat_001");
		category.setCat_name("Laptop");
		
		categoryDAO.saveOrUpdate(category);
		
	//System.out.println (  categoryDAO.list().size()  );
		//categoryDAO.delete("C");
		
	}
}
