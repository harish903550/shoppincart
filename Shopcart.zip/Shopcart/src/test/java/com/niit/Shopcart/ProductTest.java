package com.niit.Shopcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niiit.Shopcart.DAO.ProductDAO;
import com.niit.Shopcart.model.Product;

public class ProductTest {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		Product product = (Product) context.getBean("product");
		
	product.setPro_id("HA789");
	product.setPro_name("Sony");
	product.setPro_Price("100000");
	
	   productDAO.saveOrUpdate(product);
	   
	  productDAO.delete("HA789");
		
		
	}
}
