package com.niit.Shopcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niiit.Shopcart.DAO.SupplierDAO;
import com.niit.Shopcart.model.Supplier;







public class SupplierTest {
 
	public static void main(String[] args) {
	
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("supplierDAO");
		Supplier supplier = (Supplier) context.getBean("supplier");
		
	supplier.setSup_addr("VijayNagar #21 1st floor");
	supplier.setSup_id("SUP_001");
	supplier.setSup_name("sangeetha");	
	
	
	supplierDAO.saveOrUpdate(supplier);
	//supplierDAO.delete("fHA99000000D");
	}
}
