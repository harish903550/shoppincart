package com.niit.Shopcart;

import java.util.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niiit.Shopcart.DAO.UsersDAO;
import com.niit.Shopcart.model.Users;


public class UserTest {
	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.Shopcart");
		context.refresh();
		
		UsersDAO usersDAO = (UsersDAO) context.getBean("usersDAO");
		Users users = (Users) context.getBean("users");

		
		users.setUse_Addr("Malleswaram #22 2st floor");
		users.setUse_Emailid("harishmyoyo@gmail.com");
		users.setUse_name("harish");
		users.setUse_password("7890");
		users.setUse_PH("566066");
		
		usersDAO.saveOrUpdate(users);
	usersDAO.isValiduser("hari", "123456");
	}

   

}
