package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndView;

import com.niiit.Shopcart.DAO.UsersDAO;
import com.niit.Shopcart.model.Users;

@Controller
public class UserController 
{
	@Autowired
   private UsersDAO usersDAO;
	
	@Autowired
    private Users users;
	
	@RequestMapping("/")
public String getlanding(){
		return "index";
	}
	
	@RequestMapping("/about")
	public String getAbout(){
			return "Aboutus";
	}
	@RequestMapping("/contact")
	public String getContact(){
			return "Contactus";
		}
	
	@RequestMapping("/loginHere")
	public String getLogin() {
		return "Login";
	}
	
	@RequestMapping("/check")
	public ModelAndView login(@RequestParam(value = "use_name") String use_name,
			                  @RequestParam(value = "use_password") String use_password) {
		ModelAndView mv= new ModelAndView("home");
		boolean isValiduser = usersDAO.isValiduser(use_name, use_password);
		
	if (isValiduser == true) {
		mv = new ModelAndView("/Loggedin");
	} else {
		
		mv = new ModelAndView("/Login");
		mv.addObject("msg", "Invalid User");
		}
		return mv;
	}
}
